#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_mixer.h"
#include "SDL/SDL_ttf.h"
#include "perso.h"

int main()
{
SDL_Init(SDL_INIT_VIDEO);

personnage c ;
background back ;
SDL_Event event;
SDL_Surface *screen=NULL;
int go=1;

back.posbg.x=0;
back.posbg.y=0;

back.background=IMG_Load("background.png");


screen=SDL_SetVideoMode(1280, 720, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
SDL_BlitSurface(back.background, NULL, screen, &back.posbg);
SDL_Flip(screen);

c=initperso(c);

affichageperso(c,screen);
SDL_EnableKeyRepeat(100,100);
while(go)
{
SDL_WaitEvent(&event);
switch(event.type)
        {
	case SDL_KEYDOWN:
            switch(event.key.keysym.sym)
            	{	
		case SDLK_RIGHT:
			c.direction=1;
			animperso(&c,screen);
			mouvement (&c ,screen);
			
		break;
		case SDLK_LEFT: 
			c.direction=0;
			animperso(&c,screen);
			mouvement (&c ,screen);
		break;
		case SDLK_ESCAPE:
			go = 0;
		break;	
		default : 
			c.direction=-1;
			animperso(&c,screen);
		
		}
          }
SDL_BlitSurface(back.background, NULL, screen, &back.posbg);
affichageperso(c,screen);
SDL_Flip(screen);
}
freesurfaceperso(&c);
SDL_FreeSurface(back.background);
SDL_Quit();
return 0;
}

